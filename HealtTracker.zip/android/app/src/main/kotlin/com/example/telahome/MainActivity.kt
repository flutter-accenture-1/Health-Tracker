package com.example.telahome

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
